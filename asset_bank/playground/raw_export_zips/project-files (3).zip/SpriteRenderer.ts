export interface SpriteActionConfig {
  imageUrl: string;
  totalFrames: number;
  frameWidth: number;
  frameHeight: number;
  fps: number;
  loop?: boolean;
}

export interface SpriteAnimationState {
  currentAction: string;
  currentFrame: number;
  timer: number;
}

export class SpriteRenderer {
  private configs: Record<string, SpriteActionConfig>;

  constructor(configs: Record<string, SpriteActionConfig>) {
    this.configs = configs;
  }

  /**
   * Advances the animation state based on delta time.
   */
  getNextState(
    currentState: SpriteAnimationState,
    deltaTime: number
  ): SpriteAnimationState {
    const config = this.configs[currentState.currentAction];
    if (!config) return currentState;

    const nextState = { ...currentState };
    nextState.timer += deltaTime;
    const frameDuration = 1 / Math.max(1, config.fps);

    if (nextState.timer >= frameDuration) {
      const framesToAdvance = Math.floor(nextState.timer / frameDuration);
      nextState.timer %= frameDuration;
      const nextFrame = nextState.currentFrame + framesToAdvance;

      if (config.loop === false) {
        if (nextFrame >= config.totalFrames) {
          nextState.currentFrame = config.totalFrames - 1;
        } else {
          nextState.currentFrame = nextFrame;
        }
      } else {
        nextState.currentFrame = nextFrame % config.totalFrames;
      }
    }
    return nextState;
  }

  /**
   * Draws the sprite to the canvas using preloaded images.
   */
  draw(
    ctx: CanvasRenderingContext2D,
    state: SpriteAnimationState,
    x: number,
    y: number,
    width: number,
    height: number,
    loadedImages: Record<string, HTMLImageElement | null>,
    flipX = false
  ) {
    const config = this.configs[state.currentAction];
    if (!config) return;

    const img = loadedImages[config.imageUrl];

    if (!img || !img.complete || img.naturalWidth === 0) {
      ctx.fillStyle = '#6366f1';
      ctx.fillRect(x - width / 2, y - height / 2, width, height);
      return;
    }

    const framesPerRow = Math.max(1, Math.floor(img.naturalWidth / config.frameWidth));
    const safeFrame = Math.min(Math.max(0, state.currentFrame), config.totalFrames - 1);
    const sourceX = (safeFrame % framesPerRow) * config.frameWidth;
    const sourceY = Math.floor(safeFrame / framesPerRow) * config.frameHeight;

    ctx.save();
    ctx.translate(x, y);
    if (flipX) {
      ctx.scale(-1, 1);
    }

    ctx.drawImage(
      img,
      sourceX,
      sourceY,
      config.frameWidth,
      config.frameHeight,
      -width / 2,
      -height / 2,
      width,
      height
    );

    ctx.restore();
  }
}
