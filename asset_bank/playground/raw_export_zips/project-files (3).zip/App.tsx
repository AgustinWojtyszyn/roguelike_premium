// tslint:disable
/* eslint-disable */
import {
  Activity,
  ArrowLeft,
  Flame,
  HelpCircle,
  Menu,
  Pause,
  Play,
  RotateCw,
  Shield,
  Sparkles,
  Sword,
  Volume2,
  VolumeX,
  X,
  Zap,
} from 'lucide-react';
import React, {useCallback, useEffect, useRef, useState} from 'react';
import {CONFIG, getConfig, THEME} from './constants';
import {
  SpriteActionConfig,
  SpriteAnimationState,
  SpriteRenderer,
} from './SpriteRenderer';
import BackgroundMusic from './utils/BackgroundMusic';
import {
  createFixedStepper,
  drawAsset,
  drawBackground,
  Entity,
  formatTime,
  gameAudio,
  GameState,
  MenuOverlay,
  Overlay,
  prepareCanvas,
  useAssets,
  useAutoFocus,
  useInput,
  useIsMobile,
} from './utils/helper';
import {
  usePlayground,
  usePlaygroundGameLifecycle,
  useRpc,
} from './utils/usePlayground';

// --- ASSET MANIFEST DEFINITIONS ---
const ASSETS_MANIFEST: Record<string, string> = {
  // Backgrounds
  bg_title_screen: 'assets/images/bg_title_screen.png',
  bg_machine_empire: 'assets/images/bg_machine_empire.png',
  bg_machine_arena: 'assets/images/bg_machine_arena.png',
  bg_jade_empire: 'assets/images/bg_jade_empire.png',
  bg_jade_arena: 'assets/images/bg_jade_arena.png',
  bg_scarlet_fortress: 'assets/images/bg_scarlet_fortress.png',
  bg_scarlet_arena: 'assets/images/bg_scarlet_arena.png',
  bg_fractured_dimension: 'assets/images/bg_fractured_dimension.png',
  bg_fractured_arena: 'assets/images/bg_fractured_arena.png',

  // Hero Explorer
  hero_explorer_idle: 'assets/images/hero_explorer_idle.png',
  hero_explorer_run: 'assets/images/hero_explorer_run.png',
  hero_explorer_walk: 'assets/images/hero_explorer_walk.png',
  hero_explorer_shoot: 'assets/images/hero_explorer_shoot.png',
  hero_explorer_hurt: 'assets/images/hero_explorer_hurt.png',
  hero_explorer_death: 'assets/images/hero_explorer_death.png',

  // Hero Iron Warden
  hero_iron_warden_idle: 'assets/images/hero_iron_warden_idle.png',
  hero_iron_warden_run: 'assets/images/hero_iron_warden_run.png',
  hero_iron_warden_walk: 'assets/images/hero_iron_warden_walk.png',
  hero_iron_warden_sword_attack: 'assets/images/hero_iron_warden_sword_attack.png',
  hero_iron_warden_hurt: 'assets/images/hero_iron_warden_hurt.png',
  hero_iron_warden_death: 'assets/images/hero_iron_warden_death.png',

  // Enemies
  enemy_machine_scout_idle: 'assets/images/enemy_machine_scout_idle.png',
  enemy_machine_scout_run: 'assets/images/enemy_machine_scout_run.png',
  enemy_machine_scout_shoot: 'assets/images/enemy_machine_scout_shoot.png',
  enemy_machine_scout_hurt: 'assets/images/enemy_machine_scout_hurt.png',
  enemy_machine_scout_death: 'assets/images/enemy_machine_scout_death.png',

  enemy_jade_guardian_idle: 'assets/images/enemy_jade_guardian_idle.png',
  enemy_jade_guardian_walk: 'assets/images/enemy_jade_guardian_walk.png',
  enemy_jade_guardian_attack: 'assets/images/enemy_jade_guardian_attack.png',
  enemy_jade_guardian_hurt: 'assets/images/enemy_jade_guardian_hurt.png',
  enemy_jade_guardian_death: 'assets/images/enemy_jade_guardian_death.png',

  enemy_scarlet_knight_idle: 'assets/images/enemy_scarlet_knight_idle.png',
  enemy_scarlet_knight_run: 'assets/images/enemy_scarlet_knight_run.png',
  enemy_scarlet_knight_sword_attack: 'assets/images/enemy_scarlet_knight_sword_attack.png',
  enemy_scarlet_knight_hurt: 'assets/images/enemy_scarlet_knight_hurt.png',
  enemy_scarlet_knight_death: 'assets/images/enemy_scarlet_knight_death.png',

  enemy_fractured_knight_idle: 'assets/images/enemy_fractured_knight_idle.png',
  enemy_fractured_knight_run: 'assets/images/enemy_fractured_knight_run.png',
  enemy_fractured_knight_attack: 'assets/images/enemy_fractured_knight_attack.png',
  enemy_fractured_knight_hurt: 'assets/images/enemy_fractured_knight_hurt.png',
  enemy_fractured_knight_death: 'assets/images/enemy_fractured_knight_death.png',

  // Bosses
  boss_iron_colossus_idle: 'assets/images/boss_iron_colossus_idle.png',
  boss_iron_colossus_walk: 'assets/images/boss_iron_colossus_walk.png',
  boss_iron_colossus_attack: 'assets/images/boss_iron_colossus_attack.png',
  boss_iron_colossus_hurt: 'assets/images/boss_iron_colossus_hurt.png',
  boss_iron_colossus_death: 'assets/images/boss_iron_colossus_death.png',

  boss_jade_serpent: 'assets/images/boss_jade_serpent.png',

  boss_hollow_king_idle: 'assets/images/boss_hollow_king_idle.png',
  boss_hollow_king_walk: 'assets/images/boss_hollow_king_walk.png',
  boss_hollow_king_sword_attack: 'assets/images/boss_hollow_king_sword_attack.png',
  boss_hollow_king_hurt: 'assets/images/boss_hollow_king_hurt.png',
  boss_hollow_king_death: 'assets/images/boss_hollow_king_death.png',

  boss_reality_architect_idle: 'assets/images/boss_reality_architect_idle.png',
  boss_reality_architect_walk: 'assets/images/boss_reality_architect_walk.png',
  boss_reality_architect_attack: 'assets/images/boss_reality_architect_attack.png',
  boss_reality_architect_hurt: 'assets/images/boss_reality_architect_hurt.png',
  boss_reality_architect_death: 'assets/images/boss_reality_architect_death.png',

  // Weapons
  weapon_assault_rifle: 'assets/images/weapon_assault_rifle.png',
  weapon_ancient_sword: 'assets/images/weapon_ancient_sword.png',
  weapon_heavy_crossbow: 'assets/images/weapon_heavy_crossbow.png',
  weapon_celestial_railgun: 'assets/images/weapon_celestial_railgun.png',
  weapon_plasma_cannon: 'assets/images/weapon_plasma_cannon.png',
  weapon_dual_daggers: 'assets/images/weapon_dual_daggers.png',
  weapon_energy_shotgun: 'assets/images/weapon_energy_shotgun.png',
  weapon_magical_staff: 'assets/images/weapon_magical_staff.png',

  // Props & Pickups
  prop_chest_common: 'assets/images/prop_chest_common.png',
  prop_chest_rare: 'assets/images/prop_chest_rare.png',
  prop_chest_legendary: 'assets/images/prop_chest_legendary.png',
  prop_weapon_pedestal: 'assets/images/prop_weapon_pedestal.png',
  prop_healing_shrine: 'assets/images/prop_healing_shrine.png',
  prop_magic_altar: 'assets/images/prop_magic_altar.png',
  prop_teleport_portal: 'assets/images/prop_teleport_portal.png',
  prop_destructible_crate: 'assets/images/prop_destructible_crate.png',
  prop_explosive_barrel: 'assets/images/prop_explosive_barrel.png',
  prop_health_pickup: 'assets/images/prop_health_pickup.png',
  prop_crystal_pickup: 'assets/images/prop_crystal_pickup.png',
  prop_coin_pickup: 'assets/images/prop_coin_pickup.png',

  // VFX
  fx_sword_slash: 'assets/images/fx_sword_slash.png',
  fx_explosion: 'assets/images/fx_explosion.png',
  fx_dash_trail: 'assets/images/fx_dash_trail.png',
  fx_electric_impact: 'assets/images/fx_electric_impact.png',
  fx_muzzle_flash: 'assets/images/fx_muzzle_flash.png',
  fx_heal_pulse: 'assets/images/fx_heal_pulse.png',
  fx_shield_break: 'assets/images/fx_shield_break.png',
  fx_death_particles: 'assets/images/fx_death_particles.png',
};

// --- WEAPON TYPES & SPECS ---
interface WeaponDef {
  id: string;
  name: string;
  type: 'ranged' | 'melee' | 'beam' | 'spread' | 'explosive';
  assetKey: string;
  damage: number;
  fireRate: number; // shots per sec
  range: number;
  bulletSpeed: number;
  bulletSize: number;
  color: string;
  spreadAngle?: number;
  pelletCount?: number;
  explosionRadius?: number;
  pierce?: number;
  description: string;
}

const WEAPONS: Record<string, WeaponDef> = {
  assault_rifle: {
    id: 'assault_rifle',
    name: 'Kinetic Assault Rifle',
    type: 'ranged',
    assetKey: 'weapon_assault_rifle',
    damage: 22,
    fireRate: 6.5,
    range: 650,
    bulletSpeed: 700,
    bulletSize: 6,
    color: '#38bdf8',
    description: 'Rapid-fire kinetic rifle with pinpoint accuracy.',
  },
  ancient_sword: {
    id: 'ancient_sword',
    name: 'Runic Bastard Sword',
    type: 'melee',
    assetKey: 'weapon_ancient_sword',
    damage: 65,
    fireRate: 2.2,
    range: 130,
    bulletSpeed: 0,
    bulletSize: 60,
    color: '#22d3ee',
    description: 'Heavy damascus greatsword that carves wide sweeping arcs.',
  },
  heavy_crossbow: {
    id: 'heavy_crossbow',
    name: 'Siege Crossbow',
    type: 'ranged',
    assetKey: 'weapon_heavy_crossbow',
    damage: 85,
    fireRate: 1.4,
    range: 850,
    bulletSpeed: 850,
    bulletSize: 8,
    color: '#fbbf24',
    pierce: 3,
    description: 'Piercing high-velocity mechanical bolt launcher.',
  },
  celestial_railgun: {
    id: 'celestial_railgun',
    name: 'Celestial Railgun',
    type: 'beam',
    assetKey: 'weapon_celestial_railgun',
    damage: 130,
    fireRate: 0.9,
    range: 1000,
    bulletSpeed: 1400,
    bulletSize: 10,
    color: '#c084fc',
    pierce: 99,
    description: 'Electromagnetic particle beam piercing all dimensional barriers.',
  },
  plasma_cannon: {
    id: 'plasma_cannon',
    name: 'Heavy Plasma Cannon',
    type: 'explosive',
    assetKey: 'weapon_plasma_cannon',
    damage: 110,
    fireRate: 1.1,
    range: 700,
    bulletSpeed: 450,
    bulletSize: 14,
    color: '#f97316',
    explosionRadius: 120,
    description: 'Fires volatile plasma orbs that detonate in fiery bursts.',
  },
  dual_daggers: {
    id: 'dual_daggers',
    name: 'Shadowstrike Daggers',
    type: 'melee',
    assetKey: 'weapon_dual_daggers',
    damage: 32,
    fireRate: 5.5,
    range: 90,
    bulletSpeed: 0,
    bulletSize: 40,
    color: '#a855f7',
    description: 'Ultra-fast venomous twin blades tearing foes to ribbons.',
  },
  energy_shotgun: {
    id: 'energy_shotgun',
    name: 'Energy Scattergun',
    type: 'spread',
    assetKey: 'weapon_energy_shotgun',
    damage: 18,
    fireRate: 2.0,
    range: 480,
    bulletSpeed: 600,
    bulletSize: 7,
    color: '#34d399',
    pelletCount: 6,
    spreadAngle: 0.45,
    description: 'Blasts 6 high-intensity energetic pellets in a devastating cone.',
  },
  magical_staff: {
    id: 'magical_staff',
    name: 'Astral Archmage Staff',
    type: 'ranged',
    assetKey: 'weapon_magical_staff',
    damage: 48,
    fireRate: 3.0,
    range: 680,
    bulletSpeed: 520,
    bulletSize: 12,
    color: '#ec4899',
    pierce: 1,
    description: 'Channels astral orbs seeking nearby dimensional anomalies.',
  },
};

type HeroId = 'explorer' | 'iron_warden';

interface HeroSpec {
  id: HeroId;
  name: string;
  title: string;
  avatarAction: string;
  baseHp: number;
  baseShield: number;
  speedMod: number;
  startingWeapon: string;
  abilityName: string;
  abilityDesc: string;
  color: string;
}

const HEROES: Record<HeroId, HeroSpec> = {
  explorer: {
    id: 'explorer',
    name: 'The Explorer',
    title: 'Voidfarer Marksman',
    avatarAction: 'hero_explorer_idle',
    baseHp: 100,
    baseShield: 20,
    speedMod: 1.15,
    startingWeapon: 'assault_rifle',
    abilityName: 'Dimensional Overclock',
    abilityDesc: 'Triple fire rate and piercing lasers for 5 seconds.',
    color: '#38bdf8',
  },
  iron_warden: {
    id: 'iron_warden',
    name: 'The Iron Warden',
    title: 'Bastion of the Realm',
    avatarAction: 'hero_iron_warden_idle',
    baseHp: 160,
    baseShield: 50,
    speedMod: 0.95,
    startingWeapon: 'ancient_sword',
    abilityName: 'Aegis Shockwave',
    abilityDesc: 'Emanates a 360-degree shockwave clearing bullets and crushing foes.',
    color: '#fbbf24',
  },
};

// --- REALM / WORLD DEFINITIONS ---
interface WorldDef {
  id: number;
  name: string;
  subtitle: string;
  bgExplore: string;
  bgArena: string;
  enemyType: string;
  bossId: string;
  bossName: string;
  themeColor: string;
  killGoal: number;
}

const WORLDS: WorldDef[] = [
  {
    id: 1,
    name: 'Corrupted Machine Empire',
    subtitle: 'Rusted furnaces & mechanical sentinels',
    bgExplore: 'bg_machine_empire',
    bgArena: 'bg_machine_arena',
    enemyType: 'machine_scout',
    bossId: 'iron_colossus',
    bossName: 'The Iron Colossus',
    themeColor: '#f59e0b',
    killGoal: 15,
  },
  {
    id: 2,
    name: 'Ancient Jade Empire',
    subtitle: 'Sacred stone temples & coiled serpents',
    bgExplore: 'bg_jade_empire',
    bgArena: 'bg_jade_arena',
    enemyType: 'jade_guardian',
    bossId: 'jade_serpent',
    bossName: 'Jade Serpent Sovereign',
    themeColor: '#10b981',
    killGoal: 20,
  },
  {
    id: 3,
    name: 'Scarlet Ruined Fortress',
    subtitle: 'Blood-red skies & gothic dread',
    bgExplore: 'bg_scarlet_fortress',
    bgArena: 'bg_scarlet_arena',
    enemyType: 'scarlet_knight',
    bossId: 'hollow_king',
    bossName: 'The Hollow King',
    themeColor: '#ef4444',
    killGoal: 25,
  },
  {
    id: 4,
    name: 'Fractured Dimension',
    subtitle: 'Astral singularities & Reality Architects',
    bgExplore: 'bg_fractured_dimension',
    bgArena: 'bg_fractured_arena',
    enemyType: 'fractured_knight',
    bossId: 'reality_architect',
    bossName: 'The Reality Architect',
    themeColor: '#8b5cf6',
    killGoal: 30,
  },
];

// --- SIMULATION DATA STRUCTURES ---
interface PlayerEntity extends Entity {
  heroId: HeroId;
  hp: number;
  maxHp: number;
  shield: number;
  maxShield: number;
  crystals: number;
  coins: number;
  currentWeapon: WeaponDef;
  secondaryWeapon: WeaponDef | null;
  dashTimer: number;
  dashCooldown: number;
  isDashing: boolean;
  dashDir: {x: number; y: number};
  abilityCooldown: number;
  abilityActiveTimer: number;
  facingLeft: boolean;
  invulnerableTimer: number;
  animState: SpriteAnimationState;
  fireCooldown: number;
  statBonusDmg: number;
  statBonusSpeed: number;
  statBonusCrit: number;
}

interface BulletEntity {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  damage: number;
  rangeRemaining: number;
  isPlayer: boolean;
  pierce: number;
  explosionRadius?: number;
}

interface EnemyEntity {
  id: number;
  type: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  scoreValue: number;
  facingLeft: boolean;
  animState: SpriteAnimationState;
  shootCooldown: number;
  isBoss: boolean;
  bossPhase: number;
  specialAttackTimer: number;
  deathTimer: number;
  isDead: boolean;
}

interface PropItem {
  id: number;
  type:
    | 'chest_common'
    | 'chest_rare'
    | 'chest_legendary'
    | 'pedestal'
    | 'shrine'
    | 'altar'
    | 'portal'
    | 'crate'
    | 'barrel';
  x: number;
  y: number;
  width: number;
  height: number;
  opened: boolean;
  weaponDrop?: WeaponDef;
  hp?: number;
  exploded?: boolean;
}

interface PickupItem {
  id: number;
  type: 'heart' | 'crystal' | 'coin';
  x: number;
  y: number;
  vx: number;
  vy: number;
  value: number;
}

interface ParticleVFX {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
  alpha: number;
  assetKey?: string;
  rotation?: number;
  rotSpeed?: number;
}

interface FloaterText {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
  maxLife: number;
  vy: number;
}

interface TelegraphZone {
  x: number;
  y: number;
  radius: number;
  timer: number;
  maxTimer: number;
  damage: number;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stepperRef = useRef<ReturnType<typeof createFixedStepper>>();
  const lastCancelRef = useRef(false);
  const isMobile = useIsMobile();

  // --- PLAYGROUND SDK ---
  const {sdk} = usePlayground();
  const [exitChat] = useRpc<Record<string, unknown>, void>('ExitChat');

  // --- ASSETS PRELOADING ---
  const {assets, isReady: assetsReady} = useAssets(ASSETS_MANIFEST);

  const canvasWidth = getConfig('baseCanvasWidth') as number;
  const canvasHeight = getConfig('baseCanvasHeight') as number;
  const worldWidth = 2400;
  const worldHeight = 1600;

  if (!stepperRef.current) {
    stepperRef.current = createFixedStepper(
      getConfig('stepMs') as number,
      getConfig('maxSubSteps') as number,
    );
  }

  // --- GAME STATE ---
  const [gameState, setGameState] = useState<GameState>({
    status: 'START',
    score: 0,
    level: 1,
    lives: 3,
  });
  const gameStateRef = useRef(gameState);
  gameStateRef.current = gameState;

  // Selected Hero
  const [selectedHero, setSelectedHero] = useState<HeroId>('explorer');
  const [isGameMenuOpen, setIsGameMenuOpen] = useState(false);
  const [isHowToPlayOpen, setIsHowToPlayOpen] = useState(false);
  const [isMusicMuted, setIsMusicMuted] = useState(false);
  const [isSfxMuted, setIsSfxMuted] = useState(false);

  // Focus ref for primary buttons
  const startButtonRef = useAutoFocus<HTMLButtonElement>(
    gameState.status === 'START',
  );

  // HUD and Interactive reactive mirrors (updated periodically or on triggers)
  const [hudStats, setHudStats] = useState({
    hp: 100,
    maxHp: 100,
    shield: 20,
    maxShield: 20,
    crystals: 0,
    coins: 0,
    currentWeaponName: 'Assault Rifle',
    secondaryWeaponName: '',
    dashCooldownPercent: 100,
    abilityCooldownPercent: 100,
    isAbilityActive: false,
    bossHpPercent: 0,
    bossName: '',
    killsRemaining: 15,
    isBossSpawned: false,
    interactPrompt: '',
  });

  // Mobile Virtual Controls State
  const mobileStickRef = useRef({
    moveActive: false,
    moveDir: {x: 0, y: 0},
    aimActive: false,
    aimDir: {x: 0, y: 0},
    firing: false,
  });

  useEffect(() => {
    (window as any).canHandleBackKey = gameState.status !== 'START';
  }, [gameState.status]);

  const inputRef = useInput(canvasRef, true, {
    width: canvasWidth,
    height: canvasHeight,
  });

  // --- SPRITE RENDERERS MAP ---
  const spriteRenderersRef = useRef<Record<string, SpriteRenderer>>({});

  // Helper to init renderers once assets ready
  const getRenderer = (type: string, configs: Record<string, SpriteActionConfig>) => {
    if (!spriteRenderersRef.current[type]) {
      spriteRenderersRef.current[type] = new SpriteRenderer(configs);
    }
    return spriteRenderersRef.current[type];
  };

  // --- SIMULATION DATA (Stored in Refs for ultra 60fps performance) ---
  const playerRef = useRef<PlayerEntity>({
    id: 'player',
    type: 'PLAYER',
    x: worldWidth / 2,
    y: worldHeight / 2,
    width: 64,
    height: 64,
    vx: 0,
    vy: 0,
    heroId: 'explorer',
    hp: 100,
    maxHp: 100,
    shield: 20,
    maxShield: 20,
    crystals: 0,
    coins: 0,
    currentWeapon: WEAPONS.assault_rifle,
    secondaryWeapon: null,
    dashTimer: 0,
    dashCooldown: 0,
    isDashing: false,
    dashDir: {x: 1, y: 0},
    abilityCooldown: 0,
    abilityActiveTimer: 0,
    facingLeft: false,
    invulnerableTimer: 0,
    animState: {currentAction: 'idle', currentFrame: 0, timer: 0},
    fireCooldown: 0,
    statBonusDmg: 1.0,
    statBonusSpeed: 1.0,
    statBonusCrit: 0,
  });

  const bulletsRef = useRef<BulletEntity[]>([]);
  const enemiesRef = useRef<EnemyEntity[]>([]);
  const propsRef = useRef<PropItem[]>([]);
  const pickupsRef = useRef<PickupItem[]>([]);
  const particlesRef = useRef<ParticleVFX[]>([]);
  const floatersRef = useRef<FloaterText[]>([]);
  const telegraphsRef = useRef<TelegraphZone[]>([]);

  const cameraRef = useRef({x: worldWidth / 2, y: worldHeight / 2});
  const screenShakeRef = useRef(0);
  const hitStopTimerRef = useRef(0);
  const waveKillsRef = useRef(0);
  const currentWorldIndexRef = useRef(0);
  const isBossActiveRef = useRef(false);
  const nextBulletIdRef = useRef(1);
  const nextEnemyIdRef = useRef(1);
  const nextPropIdRef = useRef(1);
  const nextPickupIdRef = useRef(1);
  const nextFloaterIdRef = useRef(1);

  // Setup / Spawn World Level
  const initWorld = useCallback((worldIdx: number, heroId: HeroId, preserveStats = true) => {
    currentWorldIndexRef.current = worldIdx;
    waveKillsRef.current = 0;
    isBossActiveRef.current = false;
    const hero = HEROES[heroId];

    if (!preserveStats) {
      playerRef.current.heroId = heroId;
      playerRef.current.maxHp = hero.baseHp + (getConfig('playerMaxHealth') as number) - 120;
      playerRef.current.hp = playerRef.current.maxHp;
      playerRef.current.maxShield = hero.baseShield;
      playerRef.current.shield = hero.baseShield;
      playerRef.current.currentWeapon = WEAPONS[hero.startingWeapon] || WEAPONS.assault_rifle;
      playerRef.current.secondaryWeapon = null;
      playerRef.current.crystals = 0;
      playerRef.current.coins = 0;
      playerRef.current.statBonusDmg = 1.0;
      playerRef.current.statBonusSpeed = 1.0;
      playerRef.current.statBonusCrit = 0;
    }

    playerRef.current.x = worldWidth / 2;
    playerRef.current.y = worldHeight / 2;
    playerRef.current.vx = 0;
    playerRef.current.vy = 0;
    playerRef.current.dashTimer = 0;
    playerRef.current.dashCooldown = 0;
    playerRef.current.isDashing = false;
    playerRef.current.abilityActiveTimer = 0;
    playerRef.current.invulnerableTimer = 1.0;
    playerRef.current.animState = {currentAction: 'idle', currentFrame: 0, timer: 0};

    bulletsRef.current = [];
    enemiesRef.current = [];
    pickupsRef.current = [];
    particlesRef.current = [];
    floatersRef.current = [];
    telegraphsRef.current = [];

    // Populate Props (Crates, Barrels, Altars, Shrines, Chests, Pedestals)
    const newProps: PropItem[] = [];
    const worldDef = WORLDS[worldIdx];

    // Shrines & Altars
    newProps.push({
      id: nextPropIdRef.current++,
      type: 'shrine',
      x: worldWidth / 2 - 350,
      y: worldHeight / 2 - 250,
      width: 70,
      height: 70,
      opened: false,
    });
    newProps.push({
      id: nextPropIdRef.current++,
      type: 'altar',
      x: worldWidth / 2 + 350,
      y: worldHeight / 2 - 250,
      width: 80,
      height: 60,
      opened: false,
    });

    // Weapon Pedestal
    const availableWeaponKeys = Object.keys(WEAPONS).filter(
      (k) => k !== playerRef.current.currentWeapon.id,
    );
    const randomWepKey =
      availableWeaponKeys[Math.floor(Math.random() * availableWeaponKeys.length)];
    newProps.push({
      id: nextPropIdRef.current++,
      type: 'pedestal',
      x: worldWidth / 2,
      y: worldHeight / 2 - 380,
      width: 60,
      height: 60,
      opened: false,
      weaponDrop: WEAPONS[randomWepKey],
    });

    // Chests
    newProps.push({
      id: nextPropIdRef.current++,
      type: 'chest_common',
      x: worldWidth / 2 - 500,
      y: worldHeight / 2 + 300,
      width: 55,
      height: 55,
      opened: false,
    });
    newProps.push({
      id: nextPropIdRef.current++,
      type: worldIdx >= 2 ? 'chest_legendary' : 'chest_rare',
      x: worldWidth / 2 + 500,
      y: worldHeight / 2 + 300,
      width: 60,
      height: 60,
      opened: false,
    });

    // Crates and Barrels scattered around arena
    for (let i = 0; i < 14; i++) {
      const angle = (i / 14) * Math.PI * 2;
      const dist = 300 + Math.random() * 500;
      const isBarrel = i % 3 === 0;
      newProps.push({
        id: nextPropIdRef.current++,
        type: isBarrel ? 'barrel' : 'crate',
        x: worldWidth / 2 + Math.cos(angle) * dist,
        y: worldHeight / 2 + Math.sin(angle) * dist,
        width: isBarrel ? 45 : 50,
        height: isBarrel ? 60 : 50,
        hp: isBarrel ? 30 : 25,
        opened: false,
      });
    }

    propsRef.current = newProps;
  }, []);

  // Initial Game Start
  const initGame = useCallback(() => {
    setGameState((prev) => ({
      ...prev,
      status: 'PLAYING',
      score: 0,
      level: 1,
      lives: 3,
    }));
    initWorld(0, selectedHero, false);
    gameAudio.playPowerupChime();
    if (sdk) {
      sdk.startGame();
    }
  }, [initWorld, sdk, selectedHero]);

  // Autoplay support
  const hasAutoplayed = useRef(false);
  useEffect(() => {
    if (
      !hasAutoplayed.current &&
      new URLSearchParams(window.location.search).has('autoplay')
    ) {
      hasAutoplayed.current = true;
      initGame();
    }
  }, [initGame]);

  // Lifecycle reporting
  usePlaygroundGameLifecycle(gameState, sdk);

  // Sound triggers on status changes
  useEffect(() => {
    if (gameState.status === 'GAME_OVER') gameAudio.playDefeatMotif();
    if (gameState.status === 'VICTORY') gameAudio.playVictoryFanfare();
  }, [gameState.status]);

  // Spawn Enemy helper
  const spawnEnemy = (isBoss = false) => {
    const worldDef = WORLDS[currentWorldIndexRef.current];
    const spawnAngle = Math.random() * Math.PI * 2;
    const spawnDist = isBoss ? 450 : 500 + Math.random() * 300;
    const px = playerRef.current.x;
    const py = playerRef.current.y;
    const ex = Math.max(100, Math.min(worldWidth - 100, px + Math.cos(spawnAngle) * spawnDist));
    const ey = Math.max(100, Math.min(worldHeight - 100, py + Math.sin(spawnAngle) * spawnDist));

    if (isBoss) {
      isBossActiveRef.current = true;
      enemiesRef.current.push({
        id: nextEnemyIdRef.current++,
        type: worldDef.bossId,
        x: ex,
        y: ey,
        vx: 0,
        vy: 0,
        width: worldDef.bossId === 'jade_serpent' ? 140 : 120,
        height: worldDef.bossId === 'jade_serpent' ? 140 : 120,
        hp: 1200 + currentWorldIndexRef.current * 800,
        maxHp: 1200 + currentWorldIndexRef.current * 800,
        speed: 130 + currentWorldIndexRef.current * 20,
        damage: 35,
        scoreValue: 5000,
        facingLeft: false,
        animState: {currentAction: 'idle', currentFrame: 0, timer: 0},
        shootCooldown: 1.5,
        isBoss: true,
        bossPhase: 1,
        specialAttackTimer: 3.0,
        deathTimer: 0,
        isDead: false,
      });
      gameAudio.playPowerupChime();
    } else {
      enemiesRef.current.push({
        id: nextEnemyIdRef.current++,
        type: worldDef.enemyType,
        x: ex,
        y: ey,
        vx: 0,
        vy: 0,
        width: 60,
        height: 60,
        hp: 45 + currentWorldIndexRef.current * 25,
        maxHp: 45 + currentWorldIndexRef.current * 25,
        speed: 150 + Math.random() * 60,
        damage: 15 + currentWorldIndexRef.current * 5,
        scoreValue: 150,
        facingLeft: false,
        animState: {currentAction: 'idle', currentFrame: 0, timer: 0},
        shootCooldown: 1.0 + Math.random() * 2.0,
        isBoss: false,
        bossPhase: 1,
        specialAttackTimer: 0,
        deathTimer: 0,
        isDead: false,
      });
    }
  };

  // Particle Spawner
  const spawnParticles = (
    x: number,
    y: number,
    count: number,
    color: string,
    speed = 200,
    assetKey?: string,
  ) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = (Math.random() * 0.8 + 0.2) * speed;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd,
        size: Math.random() * 6 + 3,
        color,
        life: 0.4 + Math.random() * 0.4,
        maxLife: 0.8,
        alpha: 1.0,
        assetKey,
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 8,
      });
    }
  };

  // Floater text
  const addFloater = (x: number, y: number, text: string, color: string) => {
    floatersRef.current.push({
      id: nextFloaterIdRef.current++,
      x,
      y,
      text,
      color,
      life: 0.8,
      maxLife: 0.8,
      vy: -50,
    });
  };

  // --- UPDATE LOGIC ---
  const update = (dt: number) => {
    if (gameStateRef.current.status !== 'PLAYING') return;

    if (hitStopTimerRef.current > 0) {
      hitStopTimerRef.current -= dt;
      return;
    }

    const p = playerRef.current;
    const input = inputRef.current;
    const mStick = mobileStickRef.current;
    const worldDef = WORLDS[currentWorldIndexRef.current];

    // Screen Shake Decay
    if (screenShakeRef.current > 0) {
      screenShakeRef.current = Math.max(0, screenShakeRef.current - dt * 25);
    }

    // 1. Player Movement Input
    let moveX = 0;
    let moveY = 0;

    if (input.actions.left) moveX -= 1;
    if (input.actions.right) moveX += 1;
    if (input.actions.up) moveY -= 1;
    if (input.actions.down) moveY += 1;

    // Mobile Stick Override
    if (mStick.moveActive) {
      moveX = mStick.moveDir.x;
      moveY = mStick.moveDir.y;
    }

    const moveMag = Math.hypot(moveX, moveY);
    if (moveMag > 0.05) {
      moveX /= moveMag;
      moveY /= moveMag;
      p.dashDir = {x: moveX, y: moveY};
      p.facingLeft = moveX < 0;
    }

    // Dash Handling
    const baseSpeed = (getConfig('playerBaseSpeed') as number) * p.statBonusSpeed;
    const speedMult = (HEROES[p.heroId]?.speedMod || 1.0);

    if (p.dashCooldown > 0) p.dashCooldown -= dt;
    if (p.invulnerableTimer > 0) p.invulnerableTimer -= dt;

    if (p.dashTimer > 0) {
      p.dashTimer -= dt;
      const dashSpd = baseSpeed * (getConfig('dashSpeedMultiplier') as number);
      p.vx = p.dashDir.x * dashSpd;
      p.vy = p.dashDir.y * dashSpd;
      p.invulnerableTimer = 0.1;
      // Spawn trail
      if (Math.random() < 0.4) {
        spawnParticles(p.x, p.y, 2, '#38bdf8', 40, 'fx_dash_trail');
      }
      if (p.dashTimer <= 0) {
        p.isDashing = false;
      }
    } else {
      p.vx = moveX * baseSpeed * speedMult;
      p.vy = moveY * baseSpeed * speedMult;
    }

    // Move Player & Clamp World Bounds
    p.x = Math.max(40, Math.min(worldWidth - 40, p.x + p.vx * dt));
    p.y = Math.max(40, Math.min(worldHeight - 40, p.y + p.vy * dt));

    // Player Animation state
    let targetAction = 'idle';
    if (p.isDashing) {
      targetAction = 'run';
    } else if (moveMag > 0.1) {
      targetAction = 'run';
    }
    if (p.invulnerableTimer > 0 && p.invulnerableTimer < 0.4 && !p.isDashing) {
      targetAction = 'hurt';
    }

    if (p.animState.currentAction !== targetAction) {
      p.animState = {currentAction: targetAction, currentFrame: 0, timer: 0};
    }

    // Advance player sprite animation
    const heroSpriteMap: Record<string, SpriteActionConfig> = {
      idle: {
        imageUrl: `hero_${p.heroId}_idle`,
        totalFrames: 4,
        frameWidth: 512,
        frameHeight: 512,
        fps: 8,
      },
      run: {
        imageUrl: `hero_${p.heroId}_run`,
        totalFrames: 16,
        frameWidth: 512,
        frameHeight: 512,
        fps: 16,
      },
      walk: {
        imageUrl: `hero_${p.heroId}_walk`,
        totalFrames: 16,
        frameWidth: 512,
        frameHeight: 512,
        fps: 12,
      },
      shoot: {
        imageUrl: `hero_explorer_shoot`,
        totalFrames: 16,
        frameWidth: 512,
        frameHeight: 512,
        fps: 16,
      },
      sword_attack: {
        imageUrl: `hero_iron_warden_sword_attack`,
        totalFrames: 16,
        frameWidth: 512,
        frameHeight: 512,
        fps: 16,
      },
      hurt: {
        imageUrl: `hero_${p.heroId}_hurt`,
        totalFrames: 16,
        frameWidth: 512,
        frameHeight: 512,
        fps: 12,
      },
    };
    const playerRenderer = getRenderer(`player_${p.heroId}`, heroSpriteMap);
    p.animState = playerRenderer.getNextState(p.animState, dt);

    // Camera follow smoothly
    cameraRef.current.x += (p.x - cameraRef.current.x) * 0.1;
    cameraRef.current.y += (p.y - cameraRef.current.y) * 0.1;
    cameraRef.current.x = Math.max(canvasWidth / 2, Math.min(worldWidth - canvasWidth / 2, cameraRef.current.x));
    cameraRef.current.y = Math.max(canvasHeight / 2, Math.min(worldHeight - canvasHeight / 2, cameraRef.current.y));

    // Special Ability Duration & Cooldown
    if (p.abilityActiveTimer > 0) p.abilityActiveTimer -= dt;
    if (p.abilityCooldown > 0) p.abilityCooldown -= dt;

    // Aiming calculation
    let aimAngle = 0;
    if (mStick.aimActive && Math.hypot(mStick.aimDir.x, mStick.aimDir.y) > 0.1) {
      aimAngle = Math.atan2(mStick.aimDir.y, mStick.aimDir.x);
    } else {
      const mouseCanvasX = input.pointer.x;
      const mouseCanvasY = input.pointer.y;
      const mouseWorldX = mouseCanvasX - canvasWidth / 2 + cameraRef.current.x;
      const mouseWorldY = mouseCanvasY - canvasHeight / 2 + cameraRef.current.y;
      aimAngle = Math.atan2(mouseWorldY - p.y, mouseWorldX - p.x);

      // Auto Aim option
      if (getConfig('enableAutoAim') as boolean) {
        let nearestEnemy: EnemyEntity | null = null;
        let minDist = 400;
        for (const e of enemiesRef.current) {
          if (e.isDead) continue;
          const d = Math.hypot(e.x - p.x, e.y - p.y);
          if (d < minDist) {
            minDist = d;
            nearestEnemy = e;
          }
        }
        if (nearestEnemy) {
          aimAngle = Math.atan2(nearestEnemy.y - p.y, nearestEnemy.x - p.x);
        }
      }
    }

    if (Math.abs(aimAngle) > Math.PI / 2) {
      p.facingLeft = true;
    } else {
      p.facingLeft = false;
    }

    // 2. Weapon Firing Logic
    if (p.fireCooldown > 0) p.fireCooldown -= dt;
    const isFiring = input.pointer.down || mStick.firing;

    if (isFiring && p.fireCooldown <= 0) {
      const wep = p.currentWeapon;
      const isOverclocked = p.abilityActiveTimer > 0 && p.heroId === 'explorer';
      const fireInterval = 1 / (wep.fireRate * (isOverclocked ? 2.5 : 1.0));
      p.fireCooldown = fireInterval;

      const dmg = wep.damage * p.statBonusDmg * (isOverclocked ? 1.4 : 1.0);

      if (wep.type === 'melee') {
        gameAudio.playSwordClash();
        spawnParticles(
          p.x + Math.cos(aimAngle) * 45,
          p.y + Math.sin(aimAngle) * 45,
          4,
          wep.color,
          100,
          'fx_sword_slash',
        );

        // Melee sweep hitbox check
        const sweepRadius = wep.range;
        for (const e of enemiesRef.current) {
          if (e.isDead) continue;
          const dist = Math.hypot(e.x - p.x, e.y - p.y);
          if (dist < sweepRadius + e.width / 2) {
            const enemyAngle = Math.atan2(e.y - p.y, e.x - p.x);
            let angleDiff = Math.abs(aimAngle - enemyAngle);
            if (angleDiff > Math.PI) angleDiff = Math.PI * 2 - angleDiff;
            if (angleDiff < Math.PI * 0.55) {
              // Hit enemy!
              e.hp -= dmg;
              e.animState.currentAction = 'hurt';
              spawnParticles(e.x, e.y, 6, '#ef4444', 180, 'fx_electric_impact');
              addFloater(e.x, e.y - 20, Math.floor(dmg).toString(), '#38bdf8');
              gameAudio.playMeleePunch();
              screenShakeRef.current = 4;
            }
          }
        }

        // Damage breakable props
        for (const pr of propsRef.current) {
          if ((pr.type === 'crate' || pr.type === 'barrel') && !pr.opened && pr.hp) {
            const dist = Math.hypot(pr.x - p.x, pr.y - p.y);
            if (dist < sweepRadius + pr.width / 2) {
              pr.hp -= dmg;
            }
          }
        }
      } else if (wep.type === 'spread') {
        gameAudio.playGunshotBlast();
        const pellets = wep.pelletCount || 5;
        const spread = wep.spreadAngle || 0.4;
        for (let i = 0; i < pellets; i++) {
          const pAngle = aimAngle - spread / 2 + (i / (pellets - 1)) * spread;
          bulletsRef.current.push({
            id: nextBulletIdRef.current++,
            x: p.x + Math.cos(pAngle) * 25,
            y: p.y + Math.sin(pAngle) * 25,
            vx: Math.cos(pAngle) * wep.bulletSpeed,
            vy: Math.sin(pAngle) * wep.bulletSpeed,
            radius: wep.bulletSize,
            color: wep.color,
            damage: dmg,
            rangeRemaining: wep.range,
            isPlayer: true,
            pierce: wep.pierce || 0,
          });
        }
        spawnParticles(
          p.x + Math.cos(aimAngle) * 35,
          p.y + Math.sin(aimAngle) * 35,
          3,
          '#fbbf24',
          80,
          'fx_muzzle_flash',
        );
      } else if (wep.type === 'explosive') {
        gameAudio.playArcadeLaser();
        bulletsRef.current.push({
          id: nextBulletIdRef.current++,
          x: p.x + Math.cos(aimAngle) * 30,
          y: p.y + Math.sin(aimAngle) * 30,
          vx: Math.cos(aimAngle) * wep.bulletSpeed,
          vy: Math.sin(aimAngle) * wep.bulletSpeed,
          radius: wep.bulletSize,
          color: wep.color,
          damage: dmg,
          rangeRemaining: wep.range,
          isPlayer: true,
          pierce: 0,
          explosionRadius: wep.explosionRadius || 100,
        });
      } else {
        // Standard ranged / beam
        gameAudio.playArcadeLaser();
        bulletsRef.current.push({
          id: nextBulletIdRef.current++,
          x: p.x + Math.cos(aimAngle) * 30,
          y: p.y + Math.sin(aimAngle) * 30,
          vx: Math.cos(aimAngle) * wep.bulletSpeed,
          vy: Math.sin(aimAngle) * wep.bulletSpeed,
          radius: wep.bulletSize,
          color: wep.color,
          damage: dmg,
          rangeRemaining: wep.range,
          isPlayer: true,
          pierce: wep.pierce || 0,
        });
        spawnParticles(
          p.x + Math.cos(aimAngle) * 35,
          p.y + Math.sin(aimAngle) * 35,
          2,
          wep.color,
          70,
          'fx_muzzle_flash',
        );
      }
    }

    // 3. Bullet Simulation
    for (let i = bulletsRef.current.length - 1; i >= 0; i--) {
      const b = bulletsRef.current[i];
      const dist = Math.hypot(b.vx, b.vy) * dt;
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.rangeRemaining -= dist;

      let removeBullet = b.rangeRemaining <= 0;

      // Player Bullet hits Enemies
      if (b.isPlayer) {
        for (const e of enemiesRef.current) {
          if (e.isDead) continue;
          const hitDist = Math.hypot(e.x - b.x, e.y - b.y);
          if (hitDist < e.width / 2 + b.radius) {
            e.hp -= b.damage;
            e.animState.currentAction = 'hurt';
            spawnParticles(b.x, b.y, 4, b.color, 120, 'fx_electric_impact');
            addFloater(e.x, e.y - 15, Math.floor(b.damage).toString(), b.color);
            gameAudio.playCrispClick();

            if (b.explosionRadius) {
              // Area of effect detonation
              gameAudio.playChiptuneExplosion();
              screenShakeRef.current = 6;
              spawnParticles(b.x, b.y, 12, '#f97316', 220, 'fx_explosion');
              for (const otherE of enemiesRef.current) {
                if (otherE.isDead || otherE.id === e.id) continue;
                const d = Math.hypot(otherE.x - b.x, otherE.y - b.y);
                if (d < b.explosionRadius) {
                  const splashDmg = b.damage * 0.75 * (1 - d / b.explosionRadius);
                  otherE.hp -= splashDmg;
                  addFloater(otherE.x, otherE.y - 15, Math.floor(splashDmg).toString(), '#f97316');
                }
              }
            }

            if (b.pierce > 0) {
              b.pierce--;
            } else {
              removeBullet = true;
              break;
            }
          }
        }

        // Hit breakable props
        for (const pr of propsRef.current) {
          if ((pr.type === 'crate' || pr.type === 'barrel') && !pr.opened && pr.hp) {
            const hitDist = Math.hypot(pr.x - b.x, pr.y - b.y);
            if (hitDist < pr.width / 2 + b.radius) {
              pr.hp -= b.damage;
              removeBullet = true;
              break;
            }
          }
        }
      } else {
        // Enemy Bullet hits Player
        const pDist = Math.hypot(p.x - b.x, p.y - b.y);
        if (pDist < p.width / 2 + b.radius) {
          removeBullet = true;
          if (p.invulnerableTimer <= 0) {
            let actualDmg = b.damage;
            if (p.shield > 0) {
              gameAudio.playShieldBlock();
              if (p.shield >= actualDmg) {
                p.shield -= actualDmg;
                actualDmg = 0;
              } else {
                actualDmg -= p.shield;
                p.shield = 0;
                spawnParticles(p.x, p.y, 10, '#38bdf8', 150, 'fx_shield_break');
              }
            }
            if (actualDmg > 0) {
              p.hp -= actualDmg;
              p.invulnerableTimer = 0.6;
              screenShakeRef.current = 8;
              hitStopTimerRef.current = 0.05;
              gameAudio.playMeleePunch();
              addFloater(p.x, p.y - 30, `-${Math.floor(actualDmg)}`, '#ef4444');
            }
          }
        }
      }

      if (removeBullet || b.x < 0 || b.x > worldWidth || b.y < 0 || b.y > worldHeight) {
        bulletsRef.current.splice(i, 1);
      }
    }

    // 4. Props (Barrels, Crates, Shrines) Simulation
    let closestInteractPrompt = '';
    for (let i = propsRef.current.length - 1; i >= 0; i--) {
      const pr = propsRef.current[i];
      const distToPlayer = Math.hypot(pr.x - p.x, pr.y - p.y);

      // Crate / Barrel destruction check
      if ((pr.type === 'crate' || pr.type === 'barrel') && pr.hp !== undefined && pr.hp <= 0 && !pr.opened) {
        pr.opened = true;
        if (pr.type === 'barrel') {
          // Explode
          gameAudio.playChiptuneExplosion();
          screenShakeRef.current = 10;
          spawnParticles(pr.x, pr.y, 18, '#ef4444', 260, 'fx_explosion');
          // Damage nearby enemies & player
          for (const e of enemiesRef.current) {
            const ed = Math.hypot(e.x - pr.x, e.y - pr.y);
            if (ed < 160) {
              e.hp -= 150;
              addFloater(e.x, e.y - 20, '150', '#ef4444');
            }
          }
        } else {
          // Supply Crate breaks
          gameAudio.playCrispClick();
          spawnParticles(pr.x, pr.y, 8, '#b45309', 100);
          // Spawn pickups
          pickupsRef.current.push({
            id: nextPickupIdRef.current++,
            type: Math.random() < 0.4 ? 'heart' : 'crystal',
            x: pr.x,
            y: pr.y,
            vx: (Math.random() - 0.5) * 80,
            vy: (Math.random() - 0.5) * 80,
            value: 1,
          });
        }
      }

      // Proximity interaction prompts
      if (distToPlayer < 90 && !pr.opened) {
        if (pr.type === 'pedestal' && pr.weaponDrop) {
          closestInteractPrompt = `Press E / Tap: Swap [${pr.weaponDrop.name}]`;
        } else if (pr.type === 'shrine') {
          closestInteractPrompt = 'Press E / Tap: Drink Healing Springs';
        } else if (pr.type === 'altar') {
          closestInteractPrompt = 'Press E / Tap: Receive Mystic Boon';
        } else if (pr.type.startsWith('chest')) {
          closestInteractPrompt = 'Press E / Tap: Open Chest';
        } else if (pr.type === 'portal') {
          closestInteractPrompt = 'Press E / Tap: Enter Dimensional Rift Gateway';
        }
      }
    }

    // 5. Enemies AI & Wave Spawner
    const spawnRate = (getConfig('enemySpawnRate') as number);
    if (!isBossActiveRef.current && waveKillsRef.current < worldDef.killGoal) {
      if (enemiesRef.current.length < 6 && Math.random() < 0.02 * spawnRate) {
        spawnEnemy(false);
      }
    } else if (!isBossActiveRef.current && waveKillsRef.current >= worldDef.killGoal) {
      // Spawn World Boss!
      spawnEnemy(true);
      addFloater(playerRef.current.x, playerRef.current.y - 60, `WARNING: ${worldDef.bossName} Emerges!`, '#ef4444');
    }

    // Telegraphs Update
    for (let i = telegraphsRef.current.length - 1; i >= 0; i--) {
      const t = telegraphsRef.current[i];
      t.timer -= dt;
      if (t.timer <= 0) {
        // Detonate telegraph
        gameAudio.playChiptuneExplosion();
        spawnParticles(t.x, t.y, 14, '#ef4444', 240, 'fx_explosion');
        const pDist = Math.hypot(p.x - t.x, p.y - t.y);
        if (pDist < t.radius && p.invulnerableTimer <= 0) {
          p.hp -= t.damage;
          p.invulnerableTimer = 0.5;
          screenShakeRef.current = 10;
          addFloater(p.x, p.y - 30, `-${t.damage}`, '#ef4444');
        }
        telegraphsRef.current.splice(i, 1);
      }
    }

    // Update Enemy Entities
    for (let i = enemiesRef.current.length - 1; i >= 0; i--) {
      const e = enemiesRef.current[i];

      if (e.isDead) {
        e.deathTimer += dt;
        if (e.deathTimer > 0.8) {
          enemiesRef.current.splice(i, 1);
        }
        continue;
      }

      if (e.hp <= 0) {
        e.isDead = true;
        e.animState.currentAction = 'death';
        waveKillsRef.current++;
        setGameState((prev) => ({...prev, score: prev.score + e.scoreValue}));
        gameAudio.playChiptuneExplosion();
        spawnParticles(e.x, e.y, e.isBoss ? 25 : 10, '#8b5cf6', 200, 'fx_death_particles');

        // Drop Coins / Crystals / Hearts
        const drops = e.isBoss ? 8 : 2;
        for (let d = 0; d < drops; d++) {
          const randType = Math.random();
          pickupsRef.current.push({
            id: nextPickupIdRef.current++,
            type: randType < 0.4 ? 'coin' : randType < 0.75 ? 'crystal' : 'heart',
            x: e.x + (Math.random() - 0.5) * 30,
            y: e.y + (Math.random() - 0.5) * 30,
            vx: (Math.random() - 0.5) * 120,
            vy: (Math.random() - 0.5) * 120,
            value: 1,
          });
        }

        // If World Boss defeated: spawn dimensional portal or trigger Victory!
        if (e.isBoss) {
          isBossActiveRef.current = false;
          if (currentWorldIndexRef.current >= WORLDS.length - 1) {
            // Defeated Final Boss (Reality Architect)!
            setTimeout(() => {
              setGameState((prev) => ({...prev, status: 'VICTORY'}));
            }, 1200);
          } else {
            // Spawn Dimensional Portal Gateway
            propsRef.current.push({
              id: nextPropIdRef.current++,
              type: 'portal',
              x: e.x,
              y: e.y,
              width: 80,
              height: 100,
              opened: false,
            });
            addFloater(e.x, e.y - 40, 'Dimensional Rift Portal Opened!', '#38bdf8');
            gameAudio.playVictoryFanfare();
          }
        }
        continue;
      }

      // Enemy AI towards player
      const dx = p.x - e.x;
      const dy = p.y - e.y;
      const dist = Math.hypot(dx, dy);
      e.facingLeft = dx < 0;

      if (dist > 50) {
        e.vx = (dx / dist) * e.speed;
        e.vy = (dy / dist) * e.speed;
      } else {
        e.vx = 0;
        e.vy = 0;
      }

      e.x += e.vx * dt;
      e.y += e.vy * dt;

      // Enemy Attacks
      if (e.shootCooldown > 0) e.shootCooldown -= dt;

      if (e.isBoss) {
        // Boss specialized attack patterns
        if (e.specialAttackTimer > 0) e.specialAttackTimer -= dt;
        if (e.specialAttackTimer <= 0) {
          e.specialAttackTimer = 3.5;
          // Spawn Red Telegraph Zone targeting player!
          telegraphsRef.current.push({
            x: p.x,
            y: p.y,
            radius: 110,
            timer: 1.4,
            maxTimer: 1.4,
            damage: 40,
          });
          gameAudio.playArcadeLaser();
        }

        if (e.shootCooldown <= 0 && dist < 700) {
          e.shootCooldown = 1.6;
          // Multi-directional boss bullet nova
          const count = 8;
          for (let bIdx = 0; bIdx < count; bIdx++) {
            const bAngle = (bIdx / count) * Math.PI * 2 + Math.sin(Date.now() * 0.003);
            bulletsRef.current.push({
              id: nextBulletIdRef.current++,
              x: e.x,
              y: e.y,
              vx: Math.cos(bAngle) * 240,
              vy: Math.sin(bAngle) * 240,
              radius: 9,
              color: '#ef4444',
              damage: 20,
              rangeRemaining: 650,
              isPlayer: false,
              pierce: 0,
            });
          }
          gameAudio.playGunshotBlast();
        }
      } else {
        // Standard minion attacks
        if (e.type === 'machine_scout' && e.shootCooldown <= 0 && dist < 500) {
          e.shootCooldown = 2.2;
          const aimAngle = Math.atan2(dy, dx);
          bulletsRef.current.push({
            id: nextBulletIdRef.current++,
            x: e.x + Math.cos(aimAngle) * 20,
            y: e.y + Math.sin(aimAngle) * 20,
            vx: Math.cos(aimAngle) * 320,
            vy: Math.sin(aimAngle) * 320,
            radius: 6,
            color: '#f59e0b',
            damage: 15,
            rangeRemaining: 550,
            isPlayer: false,
            pierce: 0,
          });
          gameAudio.playArcadeLaser();
        } else if (dist < 55 && p.invulnerableTimer <= 0) {
          // Melee contact damage
          p.hp -= e.damage;
          p.invulnerableTimer = 0.5;
          screenShakeRef.current = 6;
          gameAudio.playMeleePunch();
          addFloater(p.x, p.y - 25, `-${e.damage}`, '#ef4444');
        }
      }

      // Enemy Sprite Animation
      if (!e.isDead) {
        e.animState.timer += dt;
        if (e.animState.timer >= 0.1) {
          e.animState.timer = 0;
          e.animState.currentFrame = (e.animState.currentFrame + 1) % 4;
        }
      }
    }

    // 6. Pickups Simulation
    for (let i = pickupsRef.current.length - 1; i >= 0; i--) {
      const pick = pickupsRef.current[i];
      pick.vx *= 0.95;
      pick.vy *= 0.95;
      pick.x += pick.vx * dt;
      pick.y += pick.vy * dt;

      // Magnet towards player
      const dist = Math.hypot(p.x - pick.x, p.y - pick.y);
      if (dist < 150) {
        pick.x += ((p.x - pick.x) / dist) * 250 * dt;
        pick.y += ((p.y - pick.y) / dist) * 250 * dt;
      }

      if (dist < 35) {
        // Collect!
        if (pick.type === 'heart') {
          p.hp = Math.min(p.maxHp, p.hp + 25);
          gameAudio.playPotionGulp();
          addFloater(p.x, p.y - 20, '+25 HP', '#10b981');
          spawnParticles(p.x, p.y, 6, '#10b981', 120, 'fx_heal_pulse');
        } else if (pick.type === 'crystal') {
          p.crystals += 1;
          gameAudio.playPowerupChime();
          addFloater(p.x, p.y - 20, '+1 Crystal', '#a855f7');
          setGameState((prev) => ({...prev, score: prev.score + 50}));
        } else if (pick.type === 'coin') {
          p.coins += 1;
          gameAudio.playCoinPickup();
          addFloater(p.x, p.y - 20, '+1 Gold', '#fbbf24');
          setGameState((prev) => ({...prev, score: prev.score + 100}));
        }
        pickupsRef.current.splice(i, 1);
      }
    }

    // 7. Particles & Floaters
    for (let i = particlesRef.current.length - 1; i >= 0; i--) {
      const pt = particlesRef.current[i];
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.life -= dt;
      pt.alpha = Math.max(0, pt.life / pt.maxLife);
      if (pt.rotation !== undefined && pt.rotSpeed !== undefined) {
        pt.rotation += pt.rotSpeed * dt;
      }
      if (pt.life <= 0) {
        particlesRef.current.splice(i, 1);
      }
    }

    for (let i = floatersRef.current.length - 1; i >= 0; i--) {
      const fl = floatersRef.current[i];
      fl.y += fl.vy * dt;
      fl.life -= dt;
      if (fl.life <= 0) {
        floatersRef.current.splice(i, 1);
      }
    }

    // 8. Player Defeat Check
    if (p.hp <= 0) {
      setGameState((prev) => ({...prev, status: 'GAME_OVER'}));
    }

    // 9. Update Reactive HUD
    const currentBoss = enemiesRef.current.find((e) => e.isBoss && !e.isDead);
    setHudStats({
      hp: Math.max(0, Math.floor(p.hp)),
      maxHp: p.maxHp,
      shield: Math.max(0, Math.floor(p.shield)),
      maxShield: p.maxShield,
      crystals: p.crystals,
      coins: p.coins,
      currentWeaponName: p.currentWeapon.name,
      secondaryWeaponName: p.secondaryWeapon ? p.secondaryWeapon.name : '',
      dashCooldownPercent: p.dashCooldown <= 0 ? 100 : Math.floor((1 - p.dashCooldown / 1.2) * 100),
      abilityCooldownPercent: p.abilityCooldown <= 0 ? 100 : Math.floor((1 - p.abilityCooldown / 15.0) * 100),
      isAbilityActive: p.abilityActiveTimer > 0,
      bossHpPercent: currentBoss ? Math.max(0, Math.floor((currentBoss.hp / currentBoss.maxHp) * 100)) : 0,
      bossName: currentBoss ? worldDef.bossName : '',
      killsRemaining: Math.max(0, worldDef.killGoal - waveKillsRef.current),
      isBossSpawned: isBossActiveRef.current,
      interactPrompt: closestInteractPrompt,
    });
  };

  // --- ACTIONS (Interact, Dash, Ability) ---
  const handleDash = () => {
    const p = playerRef.current;
    if (p.dashCooldown <= 0 && !p.isDashing) {
      p.isDashing = true;
      p.dashTimer = (getConfig('dashDuration') as number);
      p.dashCooldown = (getConfig('dashCooldown') as number);
      gameAudio.playArcadeLaser();
      spawnParticles(p.x, p.y, 8, '#38bdf8', 150, 'fx_dash_trail');
    }
  };

  const handleAbility = () => {
    const p = playerRef.current;
    if (p.abilityCooldown <= 0) {
      p.abilityCooldown = 15.0;
      gameAudio.playLevelUpStinger();
      if (p.heroId === 'explorer') {
        p.abilityActiveTimer = 5.0;
        addFloater(p.x, p.y - 40, 'OVERCLOCK ACTIVE!', '#38bdf8');
        spawnParticles(p.x, p.y, 16, '#38bdf8', 200, 'fx_electric_impact');
      } else {
        // Iron Warden Aegis Shockwave
        addFloater(p.x, p.y - 40, 'AEGIS SHOCKWAVE!', '#fbbf24');
        screenShakeRef.current = 12;
        spawnParticles(p.x, p.y, 25, '#fbbf24', 350, 'fx_explosion');
        // Clear all enemy bullets & damage enemies in large radius
        bulletsRef.current = bulletsRef.current.filter((b) => b.isPlayer);
        for (const e of enemiesRef.current) {
          if (e.isDead) continue;
          const d = Math.hypot(e.x - p.x, e.y - p.y);
          if (d < 380) {
            e.hp -= 200;
            addFloater(e.x, e.y - 20, '200', '#fbbf24');
          }
        }
      }
    }
  };

  const handleInteract = () => {
    const p = playerRef.current;
    for (const pr of propsRef.current) {
      const dist = Math.hypot(pr.x - p.x, pr.y - p.y);
      if (dist < 95 && !pr.opened) {
        if (pr.type === 'pedestal' && pr.weaponDrop) {
          const oldWep = p.currentWeapon;
          p.currentWeapon = pr.weaponDrop;
          pr.weaponDrop = oldWep;
          gameAudio.playPowerupChime();
          addFloater(p.x, p.y - 30, `Equipped ${p.currentWeapon.name}!`, '#38bdf8');
          return;
        } else if (pr.type === 'shrine') {
          pr.opened = true;
          p.hp = p.maxHp;
          p.shield = p.maxShield;
          gameAudio.playPotionGulp();
          spawnParticles(pr.x, pr.y, 18, '#10b981', 180, 'fx_heal_pulse');
          addFloater(p.x, p.y - 30, 'Full Health & Shield Restored!', '#10b981');
          return;
        } else if (pr.type === 'altar') {
          pr.opened = true;
          p.statBonusDmg += 0.25;
          p.statBonusSpeed += 0.1;
          gameAudio.playLevelUpStinger();
          spawnParticles(pr.x, pr.y, 18, '#8b5cf6', 180, 'fx_electric_impact');
          addFloater(p.x, p.y - 30, 'Boon: +25% DMG, +10% Speed!', '#8b5cf6');
          return;
        } else if (pr.type.startsWith('chest')) {
          pr.opened = true;
          gameAudio.playPowerupChime();
          spawnParticles(pr.x, pr.y, 14, '#fbbf24', 160);
          // Drop rare weapon or massive loot
          const pool = Object.keys(WEAPONS);
          const chosen = WEAPONS[pool[Math.floor(Math.random() * pool.length)]];
          p.currentWeapon = chosen;
          p.coins += 5;
          p.crystals += 3;
          addFloater(p.x, p.y - 35, `Found ${chosen.name}!`, '#fbbf24');
          return;
        } else if (pr.type === 'portal') {
          // Advance World!
          const nextIdx = currentWorldIndexRef.current + 1;
          if (nextIdx < WORLDS.length) {
            setGameState((prev) => ({...prev, level: nextIdx + 1}));
            initWorld(nextIdx, p.heroId, true);
            gameAudio.playVictoryFanfare();
          }
          return;
        }
      }
    }
  };

  // Keyboard action listener for E, Q, Spacebar
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (gameStateRef.current.status !== 'PLAYING') return;
      if (e.key === ' ' || e.code === 'Space') {
        handleDash();
      } else if (e.key === 'q' || e.key === 'Q') {
        handleAbility();
      } else if (e.key === 'e' || e.key === 'E') {
        handleInteract();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // --- DRAW / RENDER LOOP ---
  const draw = (ctx: CanvasRenderingContext2D) => {
    prepareCanvas(ctx, canvasWidth, canvasHeight);

    const worldDef = WORLDS[currentWorldIndexRef.current] || WORLDS[0];
    const bgKey = isBossActiveRef.current ? worldDef.bgArena : worldDef.bgExplore;
    const bgImage = assets[bgKey] || assets['bg_machine_empire'];

    // Screen shake offset
    let shakeX = 0;
    let shakeY = 0;
    const shakePower = screenShakeRef.current * (getConfig('screenShakeIntensity') as number);
    if (shakePower > 0) {
      shakeX = (Math.random() - 0.5) * shakePower;
      shakeY = (Math.random() - 0.5) * shakePower;
    }

    const camX = cameraRef.current.x + shakeX;
    const camY = cameraRef.current.y + shakeY;

    // 1. Draw Parallax Background
    drawBackground(
      ctx,
      bgImage,
      canvasWidth,
      canvasHeight,
      '#090d16',
      camX,
      camY,
    );

    // Save context for camera transformation
    ctx.save();
    ctx.translate(canvasWidth / 2 - camX, canvasHeight / 2 - camY);

    // Arena Boundary grid overlay
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 2;
    const gridSize = 120;
    for (let x = 0; x <= worldWidth; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, worldHeight);
      ctx.stroke();
    }
    for (let y = 0; y <= worldHeight; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(worldWidth, y);
      ctx.stroke();
    }

    // Outer arena boundary borders
    ctx.strokeStyle = worldDef.themeColor;
    ctx.lineWidth = 8;
    ctx.strokeRect(0, 0, worldWidth, worldHeight);

    // 2. Draw Telegraph Warning Zones
    for (const t of telegraphsRef.current) {
      const pct = Math.max(0, 1 - t.timer / t.maxTimer);
      ctx.save();
      ctx.fillStyle = 'rgba(239, 68, 68, 0.15)';
      ctx.beginPath();
      ctx.arc(t.x, t.y, Math.max(0, t.radius), 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = 'rgba(239, 68, 68, 0.8)';
      ctx.lineWidth = 3;
      ctx.setLineDash([8, 8]);
      ctx.beginPath();
      ctx.arc(t.x, t.y, Math.max(0, t.radius * pct), 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // 3. Draw Props (Chests, Shrines, Barrels, Altars, Pedestals, Portal)
    for (const pr of propsRef.current) {
      const propAsset = assets[`prop_${pr.type}`] || assets['prop_destructible_crate'];
      if (pr.type === 'pedestal') {
        drawAsset(ctx, assets['prop_weapon_pedestal'], pr.x - pr.width / 2, pr.y - pr.height / 2, pr.width, pr.height, () => {
          ctx.fillStyle = '#64748b';
          ctx.fillRect(pr.x - pr.width / 2, pr.y - pr.height / 2, pr.width, pr.height);
        });
        // Render weapon floating above pedestal
        if (pr.weaponDrop && assets[pr.weaponDrop.assetKey]) {
          const floatY = Math.sin(Date.now() * 0.005) * 6;
          drawAsset(
            ctx,
            assets[pr.weaponDrop.assetKey],
            pr.x - 25,
            pr.y - 45 + floatY,
            50,
            50,
            () => {},
          );
        }
      } else if (pr.type === 'portal') {
        const portalImg = assets['prop_teleport_portal'];
        const pSize = 110 + Math.sin(Date.now() * 0.006) * 10;
        ctx.save();
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 25;
        drawAsset(ctx, portalImg, pr.x - pSize / 2, pr.y - pSize / 2, pSize, pSize, () => {
          ctx.fillStyle = '#38bdf8';
          ctx.beginPath();
          ctx.arc(pr.x, pr.y, 45, 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.restore();
      } else if (!pr.opened) {
        drawAsset(ctx, propAsset, pr.x - pr.width / 2, pr.y - pr.height / 2, pr.width, pr.height, () => {
          ctx.fillStyle = pr.type === 'barrel' ? '#ef4444' : '#b45309';
          ctx.fillRect(pr.x - pr.width / 2, pr.y - pr.height / 2, pr.width, pr.height);
        });
      }
    }

    // 4. Draw Pickups (Hearts, Crystals, Coins)
    for (const pick of pickupsRef.current) {
      const pickImg =
        pick.type === 'heart'
          ? assets['prop_health_pickup']
          : pick.type === 'crystal'
          ? assets['prop_crystal_pickup']
          : assets['prop_coin_pickup'];
      const pSize = 32 + Math.sin(Date.now() * 0.008 + pick.id) * 3;
      drawAsset(ctx, pickImg, pick.x - pSize / 2, pick.y - pSize / 2, pSize, pSize, () => {
        ctx.fillStyle = pick.type === 'heart' ? '#ef4444' : pick.type === 'crystal' ? '#a855f7' : '#fbbf24';
        ctx.beginPath();
        ctx.arc(pick.x, pick.y, 12, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // 5. Draw Enemies & Bosses
    for (const e of enemiesRef.current) {
      if (e.isDead && e.deathTimer > 0.8) continue;

      if (e.type === 'jade_serpent') {
        // Jade Serpent Sovereign is a grand static dragon entity
        const serpentImg = assets['boss_jade_serpent'];
        drawAsset(ctx, serpentImg, e.x - e.width / 2, e.y - e.height / 2, e.width, e.height, () => {
          ctx.fillStyle = '#10b981';
          ctx.fillRect(e.x - e.width / 2, e.y - e.height / 2, e.width, e.height);
        });
      } else {
        // Spritesheet animated enemies
        const eType = e.isBoss ? `boss_${e.type}` : `enemy_${e.type}`;
        const actionMap: Record<string, SpriteActionConfig> = {
          idle: {
            imageUrl: `${eType}_idle`,
            totalFrames: 4,
            frameWidth: 512,
            frameHeight: 512,
            fps: 8,
          },
          run: {
            imageUrl: `${eType}_run`,
            totalFrames: 16,
            frameWidth: 512,
            frameHeight: 512,
            fps: 14,
          },
          walk: {
            imageUrl: `${eType}_walk`,
            totalFrames: 16,
            frameWidth: 512,
            frameHeight: 512,
            fps: 10,
          },
          attack: {
            imageUrl: `${eType}_attack`,
            totalFrames: 16,
            frameWidth: 512,
            frameHeight: 512,
            fps: 16,
          },
          sword_attack: {
            imageUrl: `${eType}_sword_attack`,
            totalFrames: 16,
            frameWidth: 512,
            frameHeight: 512,
            fps: 16,
          },
          shoot: {
            imageUrl: `${eType}_shoot`,
            totalFrames: 16,
            frameWidth: 512,
            frameHeight: 512,
            fps: 16,
          },
          hurt: {
            imageUrl: `${eType}_hurt`,
            totalFrames: 16,
            frameWidth: 512,
            frameHeight: 512,
            fps: 12,
          },
          death: {
            imageUrl: `${eType}_death`,
            totalFrames: 16,
            frameWidth: 512,
            frameHeight: 512,
            fps: 14,
            loop: false,
          },
        };
        const renderer = getRenderer(eType, actionMap);
        renderer.draw(ctx, e.animState, e.x, e.y, e.width, e.height, assets, e.facingLeft);
      }

      // Enemy Minion Health Bar
      if (!e.isBoss && !e.isDead && e.hp < e.maxHp) {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
        ctx.fillRect(e.x - 24, e.y - e.height / 2 - 10, 48, 6);
        ctx.fillStyle = '#ef4444';
        const hpWidth = Math.max(0, (e.hp / e.maxHp) * 48);
        ctx.fillRect(e.x - 24, e.y - e.height / 2 - 10, hpWidth, 6);
      }
    }

    // 6. Draw Player
    const p = playerRef.current;
    if (p.hp > 0) {
      const heroRenderer = spriteRenderersRef.current[`player_${p.heroId}`];
      if (heroRenderer) {
        // Flash if invulnerable
        if (p.invulnerableTimer <= 0 || Math.floor(Date.now() / 60) % 2 === 0) {
          heroRenderer.draw(ctx, p.animState, p.x, p.y, p.width, p.height, assets, p.facingLeft);
        }
      }

      // Draw Equipped Weapon in hands
      const wepAsset = assets[p.currentWeapon.assetKey];
      if (wepAsset && p.currentWeapon.type !== 'melee') {
        ctx.save();
        ctx.translate(p.x, p.y + 6);
        if (p.facingLeft) ctx.scale(-1, 1);
        drawAsset(ctx, wepAsset, 6, -14, 38, 38, () => {});
        ctx.restore();
      }

      // Shield Aura
      if (p.shield > 0) {
        ctx.save();
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 36, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    // 7. Draw Bullets
    for (const b of bulletsRef.current) {
      ctx.save();
      ctx.shadowColor = b.color;
      ctx.shadowBlur = 10;
      ctx.fillStyle = b.color;
      ctx.beginPath();
      ctx.arc(b.x, b.y, Math.max(1, b.radius), 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 8. Draw Particle VFX
    for (const pt of particlesRef.current) {
      ctx.save();
      ctx.globalAlpha = pt.alpha;
      if (pt.assetKey && assets[pt.assetKey]) {
        ctx.translate(pt.x, pt.y);
        if (pt.rotation) ctx.rotate(pt.rotation);
        drawAsset(ctx, assets[pt.assetKey], -pt.size * 2, -pt.size * 2, pt.size * 4, pt.size * 4, () => {});
      } else {
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, Math.max(0.5, pt.size), 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // 9. Draw Floating Numbers
    ctx.textAlign = 'center';
    ctx.font = 'bold 16px sans-serif';
    for (const fl of floatersRef.current) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, fl.life / fl.maxLife);
      ctx.fillStyle = fl.color;
      ctx.shadowColor = '#000000';
      ctx.shadowBlur = 4;
      ctx.fillText(fl.text, fl.x, fl.y);
      ctx.restore();
    }

    ctx.restore(); // Restore camera translation
  };

  // --- GAME LOOP ---
  const updateRef = useRef(update);
  const drawRef = useRef(draw);
  updateRef.current = update;
  drawRef.current = draw;

  useEffect(() => {
    let raf = 0;
    const loop = (time: number) => {
      // Global Pause handling
      if (inputRef.current) {
        const cancelPressed = inputRef.current.actions.cancel;
        if (cancelPressed && !lastCancelRef.current) {
          const currentStatus = gameStateRef.current.status;
          if (currentStatus === 'PLAYING') {
            setIsGameMenuOpen((prev) => !prev);
          } else if (currentStatus === 'START') {
            void exitChat({});
          } else if (['GAME_OVER', 'VICTORY'].includes(currentStatus)) {
            setGameState((prev) => ({...prev, status: 'START'}));
          }
        }
        lastCancelRef.current = cancelPressed;
      }

      if (!isGameMenuOpen && !isHowToPlayOpen) {
        stepperRef.current?.(time, (dt) => updateRef.current(dt));
      }

      const ctx = canvasRef.current?.getContext('2d');
      if (ctx) drawRef.current(ctx);

      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [isGameMenuOpen, isHowToPlayOpen, exitChat]);

  // Audio Music URL
  const musicUrl = isBossActiveRef.current
    ? 'assets/audio/bgm_boss_battle.mp3'
    : 'assets/audio/bgm_realm_theme.mp3';

  return (
    <div className="fixed inset-0 overflow-hidden touch-none flex flex-col items-center justify-center bg-slate-950 text-white font-sans select-none">
      <BackgroundMusic
        url={musicUrl}
        isPlaying={gameState.status === 'PLAYING' && !isMusicMuted}
        isMuted={isMusicMuted}
      />

      {/* Asset Loading State */}
      {!assetsReady && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 text-white">
          <Sparkles className="w-12 h-12 text-yellow-400 animate-spin mb-4" />
          <div className="text-xl font-bold tracking-widest text-yellow-400">
            ENTERING FRACTURED REALMS...
          </div>
        </div>
      )}

      {/* TOP HUD BAR */}
      {assetsReady && gameState.status === 'PLAYING' && (
        <header className="w-full bg-slate-900/90 border-b border-slate-800 px-3 py-2 flex flex-wrap items-center justify-between gap-2 z-20 shrink-0">
          {/* Left Stats: HP & Shield */}
          <div className="flex items-center gap-3">
            <div className="flex flex-col">
              <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                <span>HP: {hudStats.hp} / {hudStats.maxHp}</span>
              </div>
              <div className="w-24 md:w-36 h-2.5 bg-slate-950 rounded-full border border-slate-700 overflow-hidden">
                <div
                  className="h-full bg-emerald-500 transition-all duration-150"
                  style={{width: `${Math.max(0, (hudStats.hp / hudStats.maxHp) * 100)}%`}}
                />
              </div>
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-1 text-[11px] font-bold text-sky-400">
                <Shield size={12} />
                <span>{hudStats.shield}</span>
              </div>
              <div className="w-16 md:w-24 h-2.5 bg-slate-950 rounded-full border border-slate-700 overflow-hidden">
                <div
                  className="h-full bg-sky-400 transition-all duration-150"
                  style={{width: `${Math.max(0, (hudStats.shield / Math.max(1, hudStats.maxShield)) * 100)}%`}}
                />
              </div>
            </div>
          </div>

          {/* Center: Realm & Kills / Boss Bar */}
          <div className="flex flex-col items-center">
            <div className="text-xs md:text-sm font-black tracking-wide text-yellow-400">
              World {gameState.level}: {WORLDS[currentWorldIndexRef.current]?.name}
            </div>
            {hudStats.isBossSpawned ? (
              <div className="flex flex-col items-center mt-0.5">
                <span className="text-[10px] text-red-400 font-bold tracking-wider animate-pulse">
                  {hudStats.bossName} ({hudStats.bossHpPercent}%)
                </span>
                <div className="w-32 md:w-48 h-2 bg-slate-950 rounded-full border border-red-800 overflow-hidden">
                  <div
                    className="h-full bg-red-600 transition-all"
                    style={{width: `${hudStats.bossHpPercent}%`}}
                  />
                </div>
              </div>
            ) : (
              <div className="text-[10px] text-slate-300 font-medium">
                Sentinels Remaining: {hudStats.killsRemaining}
              </div>
            )}
          </div>

          {/* Right Resources & Menu Trigger */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-xs font-bold">
              <span className="text-yellow-400">🪙 {hudStats.coins}</span>
              <span className="text-purple-400">💎 {hudStats.crystals}</span>
              <span className="text-slate-200">Score: {gameState.score}</span>
            </div>

            <button
              onClick={() => setIsGameMenuOpen(true)}
              aria-label="Open Game Menu"
              className="w-10 h-10 min-w-[40px] min-h-[40px] rounded-lg bg-slate-800 hover:bg-slate-700 text-yellow-400 border border-slate-700 flex items-center justify-center transition-colors">
              <Menu size={20} />
            </button>
          </div>
        </header>
      )}

      {/* GAME CANVAS */}
      {assetsReady && (
        <div className="flex-1 w-full min-h-0 relative flex items-center justify-center bg-slate-950">
          <canvas
            ref={canvasRef}
            width={canvasWidth}
            height={canvasHeight}
            style={{
              aspectRatio: `${canvasWidth} / ${canvasHeight}`,
              width: `min(100%, calc(100vh * ${canvasWidth} / ${canvasHeight}))`,
            }}
            className="h-auto max-w-full max-h-full drop-shadow-2xl shadow-2xl"
          />

          {/* In-Game Interactive Prompt Overlay (e.g. Near Chest / Altar) */}
          {hudStats.interactPrompt && gameState.status === 'PLAYING' && (
            <div className="absolute bottom-20 left-1/2 -translate-x-1/2 bg-slate-900/90 border border-yellow-500/80 px-4 py-2 rounded-full shadow-lg text-yellow-300 text-xs md:text-sm font-bold flex items-center gap-2 animate-bounce pointer-events-auto cursor-pointer"
                 onClick={handleInteract}>
              <Sparkles size={16} />
              {hudStats.interactPrompt}
            </div>
          )}

          {/* MOBILE ON-SCREEN CONTROLS */}
          {isMobile && gameState.status === 'PLAYING' && (
            <div className="absolute inset-0 pointer-events-none z-30 flex flex-col justify-between p-4">
              <div className="flex justify-end pr-2" />
              {/* Bottom Touch Bar */}
              <div className="w-full flex justify-between items-end pb-2">
                {/* Left Virtual Movement Pad */}
                <div
                  className="w-32 h-32 rounded-full bg-slate-900/60 border border-slate-700 pointer-events-auto touch-none relative flex items-center justify-center"
                  onPointerDown={(e) => {
                    e.currentTarget.setPointerCapture(e.pointerId);
                    mobileStickRef.current.moveActive = true;
                  }}
                  onPointerMove={(e) => {
                    if (!mobileStickRef.current.moveActive) return;
                    const rect = e.currentTarget.getBoundingClientRect();
                    const centerX = rect.left + rect.width / 2;
                    const centerY = rect.top + rect.height / 2;
                    const dx = e.clientX - centerX;
                    const dy = e.clientY - centerY;
                    const dist = Math.hypot(dx, dy);
                    const angle = Math.atan2(dy, dx);
                    const clampedDist = Math.min(1, dist / (rect.width / 2));
                    mobileStickRef.current.moveDir = {
                      x: Math.cos(angle) * clampedDist,
                      y: Math.sin(angle) * clampedDist,
                    };
                  }}
                  onPointerUp={(e) => {
                    e.currentTarget.releasePointerCapture(e.pointerId);
                    mobileStickRef.current.moveActive = false;
                    mobileStickRef.current.moveDir = {x: 0, y: 0};
                  }}
                  onPointerCancel={() => {
                    mobileStickRef.current.moveActive = false;
                    mobileStickRef.current.moveDir = {x: 0, y: 0};
                  }}>
                  <div className="w-12 h-12 rounded-full bg-yellow-400/80 border border-yellow-200 shadow-md" />
                </div>

                {/* Right Action Touch Buttons */}
                <div className="flex flex-col gap-2 items-end pointer-events-auto">
                  <div className="flex gap-2">
                    {/* Interact Button */}
                    <button
                      onClick={handleInteract}
                      className="w-12 h-12 min-w-[48px] min-h-[48px] rounded-full bg-purple-600 hover:bg-purple-500 text-white font-bold border border-purple-400 flex items-center justify-center shadow-lg active:scale-95">
                      <Sparkles size={20} />
                    </button>

                    {/* Special Ability Button */}
                    <button
                      onClick={handleAbility}
                      disabled={hudStats.abilityCooldownPercent < 100}
                      className={`w-12 h-12 min-w-[48px] min-h-[48px] rounded-full font-bold border flex items-center justify-center shadow-lg active:scale-95 ${
                        hudStats.abilityCooldownPercent >= 100
                          ? 'bg-amber-500 hover:bg-amber-400 text-black border-amber-300'
                          : 'bg-slate-800 text-slate-500 border-slate-700'
                      }`}>
                      <Zap size={20} />
                    </button>
                  </div>

                  <div className="flex gap-2">
                    {/* Dash Button */}
                    <button
                      onClick={handleDash}
                      disabled={hudStats.dashCooldownPercent < 100}
                      className={`w-14 h-14 min-w-[56px] min-h-[56px] rounded-full font-bold border flex items-center justify-center shadow-lg active:scale-95 ${
                        hudStats.dashCooldownPercent >= 100
                          ? 'bg-sky-500 hover:bg-sky-400 text-black border-sky-300'
                          : 'bg-slate-800 text-slate-500 border-slate-700'
                      }`}>
                      <Flame size={24} />
                    </button>

                    {/* Attack / Fire Hold Button */}
                    <button
                      onPointerDown={() => {
                        mobileStickRef.current.firing = true;
                      }}
                      onPointerUp={() => {
                        mobileStickRef.current.firing = false;
                      }}
                      onPointerCancel={() => {
                        mobileStickRef.current.firing = false;
                      }}
                      className="w-16 h-16 min-w-[64px] min-h-[64px] rounded-full bg-red-600 hover:bg-red-500 text-white font-black border-2 border-red-400 flex items-center justify-center shadow-xl active:scale-95">
                      <Sword size={26} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* START & HERO SELECTION SCREEN */}
      {gameState.status === 'START' && (
        <MenuOverlay tone="neutral" zIndex={40}>
          <div className="w-full max-w-lg bg-slate-900/95 border-2 border-yellow-500/80 rounded-2xl p-6 md:p-8 shadow-2xl flex flex-col items-center backdrop-blur-md">
            <h1
              className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-amber-300 to-yellow-500 text-center mb-2 tracking-wider"
              style={{fontFamily: THEME.fontFamily}}>
              FRACTURED REALMS
            </h1>
            <p className="text-slate-300 text-center text-xs md:text-sm mb-6 max-w-md">
              Traverse 4 shattered dimensions battling corrupted machines, ancient beasts, and reality architects.
            </p>

            {/* Hero Selection Cards */}
            <div className="w-full grid grid-cols-2 gap-3 mb-6">
              {(Object.keys(HEROES) as HeroId[]).map((hId) => {
                const h = HEROES[hId];
                const isSelected = selectedHero === hId;
                return (
                  <button
                    key={hId}
                    type="button"
                    onClick={() => {
                      setSelectedHero(hId);
                      gameAudio.playCrispClick();
                    }}
                    className={`flex flex-col items-center p-3 rounded-xl border-2 transition-all ${
                      isSelected
                        ? 'border-yellow-400 bg-slate-800/90 shadow-lg scale-102'
                        : 'border-slate-700 bg-slate-950/60 hover:border-slate-500 opacity-75'
                    }`}>
                    <div className="w-12 h-12 rounded-full flex items-center justify-center mb-2 border"
                         style={{backgroundColor: `${h.color}20`, borderColor: h.color}}>
                      {hId === 'explorer' ? <Zap size={24} className="text-sky-400" /> : <Sword size={24} className="text-amber-400" />}
                    </div>
                    <div className="font-bold text-sm text-white">{h.name}</div>
                    <div className="text-[10px] text-slate-400 mb-1">{h.title}</div>
                    <div className="text-[10px] text-yellow-300 font-semibold text-center">{h.abilityName}</div>
                  </button>
                );
              })}
            </div>

            {/* Start Button */}
            <button
              ref={startButtonRef}
              autoFocus
              onClick={initGame}
              data-testid="start-button"
              className="w-full bg-gradient-to-r from-yellow-400 to-amber-500 hover:from-yellow-300 hover:to-amber-400 text-slate-950 px-8 py-3.5 rounded-full font-black text-lg md:text-xl transition-all transform hover:scale-105 shadow-xl flex items-center justify-center gap-3">
              <Play size={24} />
              ENTER THE REALMS
            </button>

            {/* How to Play link */}
            <button
              onClick={() => setIsHowToPlayOpen(true)}
              className="mt-4 text-xs md:text-sm text-slate-400 hover:text-yellow-400 flex items-center gap-1.5 transition-colors">
              <HelpCircle size={16} /> How to Play & Controls
            </button>
          </div>
        </MenuOverlay>
      )}

      {/* GAME OVER OVERLAY */}
      {gameState.status === 'GAME_OVER' && (
        <Overlay
          title="REALM FRACTURED"
          description={`You perished in World ${gameState.level}. Final Score: ${gameState.score}`}
          actionLabel="TRY AGAIN"
          onAction={initGame}
          icon={<RotateCw size={24} />}
          tone="danger"
        />
      )}

      {/* VICTORY OVERLAY */}
      {gameState.status === 'VICTORY' && (
        <Overlay
          title="DIMENSIONAL SOVEREIGN"
          description={`You defeated the Reality Architect and sealed the rift! Final Score: ${gameState.score}`}
          actionLabel="PLAY AGAIN"
          onAction={initGame}
          icon={<Sparkles size={24} />}
          tone="victory"
        />
      )}

      {/* PAUSE / IN-GAME MENU OVERLAY */}
      {isGameMenuOpen && (
        <MenuOverlay tone="neutral" zIndex={50}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-yellow-500 rounded-2xl p-6 shadow-2xl flex flex-col items-center">
            <h2 className="text-3xl font-black text-yellow-400 mb-6 tracking-wide">GAME MENU</h2>

            <div className="w-full flex flex-col gap-3 mb-6">
              <button
                onClick={() => setIsGameMenuOpen(false)}
                className="w-full bg-white hover:bg-yellow-400 text-slate-950 font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors">
                <Play size={20} /> Resume Game
              </button>

              <button
                onClick={() => {
                  setIsGameMenuOpen(false);
                  initWorld(currentWorldIndexRef.current, selectedHero, true);
                }}
                className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 border border-slate-700 transition-colors">
                <RotateCw size={20} /> Restart Level
              </button>

              {/* Audio Controls */}
              <div className="grid grid-cols-2 gap-3 mt-2">
                <button
                  onClick={() => {
                    const newMuted = gameAudio.toggleMute();
                    setIsSfxMuted(newMuted);
                  }}
                  className="bg-slate-800 hover:bg-slate-700 text-white py-2.5 px-3 rounded-xl border border-slate-700 flex items-center justify-center gap-2 text-sm font-semibold">
                  {isSfxMuted ? <VolumeX size={18} className="text-red-400" /> : <Volume2 size={18} className="text-green-400" />}
                  SFX: {isSfxMuted ? 'Off' : 'On'}
                </button>

                <button
                  onClick={() => setIsMusicMuted((prev) => !prev)}
                  className="bg-slate-800 hover:bg-slate-700 text-white py-2.5 px-3 rounded-xl border border-slate-700 flex items-center justify-center gap-2 text-sm font-semibold">
                  {isMusicMuted ? <VolumeX size={18} className="text-red-400" /> : <Volume2 size={18} className="text-green-400" />}
                  Music: {isMusicMuted ? 'Off' : 'On'}
                </button>
              </div>

              <button
                onClick={() => setIsHowToPlayOpen(true)}
                className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 border border-slate-700 transition-colors mt-2 text-sm">
                <HelpCircle size={18} /> How to Play
              </button>

              <button
                onClick={() => {
                  setIsGameMenuOpen(false);
                  setGameState((prev) => ({...prev, status: 'START'}));
                }}
                className="w-full bg-red-950/60 hover:bg-red-900/80 text-red-200 font-semibold py-2.5 px-4 rounded-xl border border-red-800/80 flex items-center justify-center gap-2 transition-colors mt-2 text-sm">
                <ArrowLeft size={18} /> Quit to Main Menu
              </button>
            </div>
          </div>
        </MenuOverlay>
      )}

      {/* HOW TO PLAY SCREEN */}
      {isHowToPlayOpen && (
        <MenuOverlay tone="neutral" zIndex={60}>
          <div className="w-full max-w-lg bg-slate-900 border-2 border-yellow-500/80 rounded-2xl p-6 shadow-2xl flex flex-col text-slate-200">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-black text-yellow-400">HOW TO PLAY</h2>
              <button
                onClick={() => setIsHowToPlayOpen(false)}
                className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-3 text-xs md:text-sm text-slate-300">
              <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800">
                <div className="font-bold text-yellow-400 mb-1">🎮 Controls</div>
                <ul className="list-disc list-inside space-y-0.5 text-slate-300">
                  <li><span className="font-semibold text-white">W, A, S, D / Virtual Stick:</span> Move hero</li>
                  <li><span className="font-semibold text-white">Mouse Aim & Click / Fire:</span> Shoot / Strike</li>
                  <li><span className="font-semibold text-white">Spacebar / Dash button:</span> Tactical Dash (I-Frames)</li>
                  <li><span className="font-semibold text-white">Q / Ability button:</span> Unique Hero Special Skill</li>
                  <li><span className="font-semibold text-white">E / Interact:</span> Open chests, drink shrines, swap weapons</li>
                </ul>
              </div>

              <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800">
                <div className="font-bold text-yellow-400 mb-1">⚔️ Weapons & Arsenal</div>
                <p>Equip assault rifles, beam railguns, plasma cannons, scatterguns, and greatswords from chests and plinths.</p>
              </div>

              <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800">
                <div className="font-bold text-yellow-400 mb-1">🌌 Progression</div>
                <p>Defeat required enemy sentinels in each world to summon the Titan Boss. Slay the boss to unlock the Dimensional Rift Gateway to the next realm.</p>
              </div>
            </div>

            <button
              onClick={() => setIsHowToPlayOpen(false)}
              className="mt-6 w-full bg-yellow-400 hover:bg-yellow-300 text-black font-black py-2.5 rounded-full transition-colors">
              BACK TO GAME
            </button>
          </div>
        </MenuOverlay>
      )}
    </div>
  );
}
