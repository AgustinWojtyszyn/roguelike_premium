import {SpriteConfig} from './utils/helper';

/**
 * THEME definitions for rich atmospheric styling.
 */
export const THEME = {
  fontFamily: "'Cinzel Decorative', 'Cinzel', 'Trajan Pro', 'Palatino', Georgia, serif",
  colors: {
    machine: '#f59e0b',
    jade: '#10b981',
    scarlet: '#ef4444',
    fractured: '#8b5cf6',
    gold: '#fbbf24',
    void: '#0f172a',
  },
};

/**
 * Configuration for Fractured Realms.
 */
export const CONFIG = {
  // Game Info
  title: {
    value: 'Fractured Realms',
    type: 'string',
    label: 'Game Title',
    group: 'GAME',
  },
  baseCanvasWidth: {
    value: 1376,
    type: 'number',
    label: 'Base Canvas Width',
    group: 'GAME',
  },
  baseCanvasHeight: {
    value: 768,
    type: 'number',
    label: 'Base Canvas Height',
    group: 'GAME',
  },

  // System
  targetFPS: {
    value: 60,
    type: 'number',
    label: 'Target FPS',
    group: 'SYSTEM',
  },
  stepMs: {
    value: 1000 / 60,
    type: 'number',
    label: 'Step MS',
    group: 'SYSTEM',
  },
  maxSubSteps: {
    value: 5,
    type: 'number',
    label: 'Max Sub Steps',
    group: 'SYSTEM',
  },

  // Audio & Atmosphere
  defaultMusicVolume: {
    value: 0.5,
    type: 'number',
    label: 'Default Music Volume',
    group: 'AUDIO',
  },
  defaultSfxVolume: {
    value: 0.6,
    type: 'number',
    label: 'Default SFX Volume',
    group: 'AUDIO',
  },
  screenShakeIntensity: {
    value: 1.0,
    type: 'number',
    label: 'Screen Shake Intensity',
    group: 'Visuals',
  },

  // Gameplay & Physics Rules (Tunable in playground_config)
  playerMaxHealth: {
    value: 120,
    type: 'number',
    label: 'Player Max Health',
    group: 'Rules',
  },
  playerBaseSpeed: {
    value: 280,
    type: 'number',
    label: 'Player Base Speed',
    group: 'Physics',
  },
  dashCooldown: {
    value: 1.2,
    type: 'number',
    label: 'Dash Cooldown (s)',
    group: 'Physics',
  },
  dashDuration: {
    value: 0.22,
    type: 'number',
    label: 'Dash Duration (s)',
    group: 'Physics',
  },
  dashSpeedMultiplier: {
    value: 3.2,
    type: 'number',
    label: 'Dash Speed Multiplier',
    group: 'Physics',
  },
  enemySpawnRate: {
    value: 1.0,
    type: 'number',
    label: 'Enemy Spawn Rate Multiplier',
    group: 'Rules',
  },
  enableAutoAim: {
    value: true,
    type: 'boolean',
    label: 'Enable Auto Aim Assist',
    group: 'Rules',
  },
  scoreMultiplierBonus: {
    value: 1.5,
    type: 'number',
    label: 'Streak Score Multiplier',
    group: 'Rules',
  },

  // Asset Aspect Ratios and Base Dimensions
  bgAspectRatio: { value: 1.7916, type: 'number', label: 'BG Aspect Ratio', group: 'ASSETS' },
  bgWidth: { value: 1376, type: 'number', label: 'BG Width', group: 'ASSETS' },
  bgHeight: { value: 768, type: 'number', label: 'BG Height', group: 'ASSETS' },

  weaponAssaultRifleRatio: { value: 1.5626, type: 'number', label: 'Assault Rifle Ratio', group: 'ASSETS' },
  weaponAncientSwordRatio: { value: 1.0, type: 'number', label: 'Ancient Sword Ratio', group: 'ASSETS' },
  weaponHeavyCrossbowRatio: { value: 1.6007, type: 'number', label: 'Heavy Crossbow Ratio', group: 'ASSETS' },
  weaponCelestialRailgunRatio: { value: 1.3867, type: 'number', label: 'Celestial Railgun Ratio', group: 'ASSETS' },
  weaponPlasmaCannonRatio: { value: 1.3948, type: 'number', label: 'Plasma Cannon Ratio', group: 'ASSETS' },
  weaponDualDaggersRatio: { value: 1.1500, type: 'number', label: 'Dual Daggers Ratio', group: 'ASSETS' },
  weaponEnergyShotgunRatio: { value: 1.9414, type: 'number', label: 'Energy Shotgun Ratio', group: 'ASSETS' },
  weaponMagicalStaffRatio: { value: 0.4038, type: 'number', label: 'Magical Staff Ratio', group: 'ASSETS' },

  propChestLegendaryRatio: { value: 0.9147, type: 'number', label: 'Legendary Chest Ratio', group: 'ASSETS' },
  propChestRareRatio: { value: 1.0131, type: 'number', label: 'Rare Chest Ratio', group: 'ASSETS' },
  propChestCommonRatio: { value: 0.9720, type: 'number', label: 'Common Chest Ratio', group: 'ASSETS' },
  propWeaponPedestalRatio: { value: 1.0479, type: 'number', label: 'Weapon Pedestal Ratio', group: 'ASSETS' },
  propHealingShrineRatio: { value: 1.0262, type: 'number', label: 'Healing Shrine Ratio', group: 'ASSETS' },
  propMagicAltarRatio: { value: 1.2803, type: 'number', label: 'Magic Altar Ratio', group: 'ASSETS' },
  propTeleportPortalRatio: { value: 0.7811, type: 'number', label: 'Portal Ratio', group: 'ASSETS' },
  propDestructibleCrateRatio: { value: 0.9331, type: 'number', label: 'Crate Ratio', group: 'ASSETS' },
  propExplosiveBarrelRatio: { value: 0.6233, type: 'number', label: 'Barrel Ratio', group: 'ASSETS' },
  propHealthPickupRatio: { value: 1.0013, type: 'number', label: 'Health Pickup Ratio', group: 'ASSETS' },
  propCrystalPickupRatio: { value: 0.9354, type: 'number', label: 'Crystal Pickup Ratio', group: 'ASSETS' },
  propCoinPickupRatio: { value: 1.0492, type: 'number', label: 'Coin Pickup Ratio', group: 'ASSETS' },
  bossJadeSerpentRatio: { value: 0.9684, type: 'number', label: 'Jade Serpent Ratio', group: 'ASSETS' },

  playerSprite: {
    value: undefined as SpriteConfig | undefined,
    type: 'sprite',
    label: 'Player Sprite',
    group: 'Visuals',
  },
};

// Merge customized config values if present (injected by Playground)
const {playgroundConfig} = globalThis as {
  playgroundConfig?: Record<string, unknown>;
};
if (playgroundConfig) {
  for (const [key, value] of Object.entries(playgroundConfig)) {
    if (key in CONFIG) {
      Object.assign(CONFIG[key as keyof typeof CONFIG], {value});
    }
  }
}

/**
 * Type helper for reading values in game code
 */
export type ConfigKey = keyof typeof CONFIG;

/**
 * Gets a configuration value by key.
 * @param key The configuration key.
 * @return The configuration value.
 */
export function getConfig<K extends ConfigKey>(
  key: K,
): (typeof CONFIG)[K]['value'] {
  return CONFIG[key].value;
}

export const PRESETS = {};
